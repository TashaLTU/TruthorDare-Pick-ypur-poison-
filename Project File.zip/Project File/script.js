document.getElementById("startButton").onclick = function() {
  window.open('wlcmePg.html', '_blank');
};
