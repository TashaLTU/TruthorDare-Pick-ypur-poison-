document.addEventListener("DOMContentLoaded", function() {
// Setting up the list of available drinks
const drinks = ['Pickle Juice', 'Vinegar', 'Hot Sauce', 'Alcohol', 'Mystery Drink', 'Juice'];

// Function to randomly select and display a drink
document.getElementById('selectDrinkButton').onclick = function() {
    const randomDrinkIndex = Math.floor(Math.random() * drinks.length);
    alert(`Your Poison is: ${drinks[randomDrinkIndex]}`);
};

// Flipping the card for truth or dare
const flipCardTruth = document.getElementById('flipCardTruth');
const cardInnerTruth = document.getElementById('cardInnerTruth');
flipCardTruth.addEventListener('click', function() {
    cardInnerTruth.classList.toggle('is-flipped');
});

const flipCardDare = document.getElementById('flipCardDare');
const cardInnerDare = document.getElementById('cardInnerDare');
flipCardDare.addEventListener('click', function() {
    cardInnerDare.classList.toggle('is-flipped');
});

// Function to start the timer
function startTimer(duration, display) {
    let timer = duration;
    const countdownTimer = setInterval(function () {
        display.textContent = timer + " seconds remaining";
        if (--timer < 0) {
            clearInterval(countdownTimer);
            display.textContent = "Time's up! Take a shot!";
            // Additional actions when the timer finishes
        }
    }, 1000);
}
    const timerDisplay = document.getElementById("timerDisplay");
    const timerDuration = 8; // 8 seconds
    startTimer(timerDuration, timerDisplay);
    const truthQuestions = [
        "Have you ever lied about your age?",
        "What is your biggest fear?",
        "Have you ever cheated in a game",
    // Will add more truth questions here for the future
    ];
    const dareQuestions = [
        "Do 10 push-ups",
        "Sing the alphabet backward",
        "Dance for 30 seconds",
        // Will add more dare questions here for the future
    ];
    let truthIndex = 0;
    let dareIndex = 0;
    function getNextQuestion(questionType) {
        switch (questionType) {
            case "truth":
                if (truthIndex >= truthQuestions.length) {
                    truthIndex = 0; // Resets truthIndex to 0 when all questions are asked
                }
                return truthQuestions[truthIndex++];
            case "dare":
                if (dareIndex >= dareQuestions.length) {
                    dareIndex = 0; // Resets dareIndex to 0 when all questions are asked
                }
                return dareQuestions[dareIndex++];
            default:
                return "No more questions";
        }
    }
document.getElementById("nextButton").addEventListener("click", function() {
        const truthQuestion = getNextQuestion("truth");
        const dareQuestion = getNextQuestion("dare");
    
document.getElementById("truthCardQuestion").textContent = truthQuestion;
        document.getElementById("dareCardQuestion").textContent = dareQuestion;
    });
});
