
// document.getElementById("b1").onclick = function() {
//   window.open('drinkChoices.html', '_blank');
// };

document.getElementById("addPlayerButton").onclick = function() {
  const playerInput = document.getElementById("playerInput");
  const playerName = playerInput.value;

  if (playerName.trim() !== "") {
    const playersList = document.getElementById("playersList");
    const listItem = document.createElement("li");
    listItem.textContent = playerName;
    playersList.appendChild(listItem);

    // Clears the input field after adding the player
    playerInput.value = '';
  } else {
    alert("Please enter a valid player name.");
  }
};

document.getElementById("createTeamsButton").onclick = function() {
  if (players.length < 4) {
    alert("You need at least 4 players to create teams.");
  } else {
    const numPlayersPerTeam = Math.floor(players.length / 2);
    const team1 = players.slice(0, numPlayersPerTeam);
    const team2 = players.slice(numPlayersPerTeam);
    console.log("Team 1:", team1);
    console.log("Team 2:", team2);
  }
};
document.getElementById("gameb").onclick = function() {
  window.location.href = 'GameStart.html', '_blank';
};