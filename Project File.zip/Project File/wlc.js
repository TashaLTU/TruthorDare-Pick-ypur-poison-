
document.getElementById("b1").onclick = function() {
  window.open('drinkChoices.html', '_blank');
};